<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/5/1
// +----------------------------------------------------------------------


namespace AppBundle\Controller\Filter;


use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;


class SessionFilter
{
    public static function doFilter(Request $request)
    {
        $allows = [
            '/v1/user/login',
            '/v1/user/register',
        ];

        if(!in_array($request->getPathInfo(), $allows)) {
            if (!(new Session())->get('user')) {
                $res = new Response('login invalid', 203);
                $res->send();
                exit();
            }
        }
    }
}