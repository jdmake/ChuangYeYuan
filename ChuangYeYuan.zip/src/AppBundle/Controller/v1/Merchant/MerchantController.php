<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/7/31
// +----------------------------------------------------------------------


namespace AppBundle\Controller\v1\Merchant;


use AppBundle\Controller\Common\CommonController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * @Route("/v1/merchant", name="merchant_join")
 */
class MerchantController extends CommonController
{
    /**
     * 企业入驻提交申请
     * @Route("/join", name="merchant_join", methods={"POST"})
     * @throws \Exception
     */
    public function joinAction()
    {
        $contacts = $this->request()->get('contacts');
        $creditCode = $this->request()->get('creditCode');
        $licensePic = $this->request()->get('licensePic');
        $logoPic = $this->request()->get('logoPic');
        $monthlyRent = $this->request()->get('monthlyRent');
        $name = $this->request()->get('name');
        $scope = $this->request()->get('scope');
        $startingTime = $this->request()->get('startingTime');
        $tel = $this->request()->get('tel');

        $data = [
            'contacts' => $contacts,
            'creditCode' => $creditCode,
            'licensePic' => $licensePic,
            'logoPic' => $logoPic,
            'monthlyRent' => $monthlyRent,
            'name' => $name,
            'scope' => $scope,
            'startingTime' => $startingTime,
            'tel' => $tel,
        ];

        $error = $this->validator($data, [
            'contacts' => new NotBlank(['message' => '联系人不能为空']),
            'creditCode' => new NotBlank(['message' => '信用代码不能为空']),
            'licensePic' => new NotBlank(['message' => '请上传营业执照']),
            'logoPic' => new NotBlank(['message' => '请上传公司logo']),
            'monthlyRent' => new NotBlank(['message' => '租多少个月不能为空']),
            'name' => new NotBlank(['message' => '企业名称不能为空']),
            'scope' => new NotBlank(['message' => '经营范围不能为空']),
            'startingTime' => new NotBlank(['message' => '起租时间不能为空']),
            'tel' => new NotBlank(['message' => '联系电话不能为空']),
        ]);

        if (count($error) > 0) {
            return $this->jsonError(1, array_shift($error));
        }

        $uid = $this->getUserSession('uid');

        // 入库
        $merchant_service = $this->get('merchant_service');
        if($merchant_service->getDetailByUid($uid)) {
            return $this->jsonError(1, '已经提交过申请了');
        }
        $id = $merchant_service->createJoinRecord($uid, $data);

        return $this->jsonSuccess('企业入驻提交申请', [
            'mid' => $id
        ]);
    }
}