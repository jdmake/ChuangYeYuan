<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/8/6
// +----------------------------------------------------------------------


namespace AppBundle\Controller\v1;


use AppBundle\Controller\Common\CommonController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

/**
 * @Route("/order")
 */
class OrderController extends CommonController
{
    /**
     * 获取订单分页列表
     * @Route("/getOrderPageList", name="order_getOrderPageList")
     */
    public function getOrderPageListAction()
    {
        $type = $this->request()->get('type');
        $page = $this->request()->get('page');
        $status = $this->request()->get('status');

        $order_service = $this->get('order_service');
        $res = $order_service->getPageList($type, $status, $page, 10);

        return $this->jsonSuccess('获取订单列表', $res);
    }
}