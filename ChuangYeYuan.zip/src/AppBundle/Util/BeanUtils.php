<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/7/8
// +----------------------------------------------------------------------


namespace AppBundle\Util;


class BeanUtils
{
    /**
     * 拷贝对象属性到目标对象
     * @param $source
     * @param $target
     */
    static public function copyProperties($source, $target) {

    }
}