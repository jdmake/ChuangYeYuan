<?php

namespace AppBundle\Entity;

/**
 * PioneerparkMember
 */
class PioneerparkMember implements \JsonSerializable, \ArrayAccess
{
    /**
     * @var integer
     */
    private $uid;

    /**
     * @var boolean
     */
    private $isenterprise;

    /**
     * @var string
     */
    private $openid;

    /**
     * @var string
     */
    private $mobile;

    /**
     * @var integer
     */
    private $level = '1';

    /**
     * @var integer
     */
    private $parentid;

    /**
     * @var float
     */
    private $credit;

    /**
     * @var string
     */
    private $lastloginip;

    /**
     * @var \DateTime
     */
    private $lastlogintime;

    /**
     * @var integer
     */
    private $profileid;

    /**
     * @var \DateTime
     */
    private $regtime;

    /**
     * @var boolean
     */
    private $enable;


    /**
     * Get uid
     *
     * @return integer
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * Set isenterprise
     *
     * @param boolean $isenterprise
     *
     * @return PioneerparkMember
     */
    public function setIsenterprise($isenterprise)
    {
        $this->isenterprise = $isenterprise;

        return $this;
    }

    /**
     * Get isenterprise
     *
     * @return boolean
     */
    public function getIsenterprise()
    {
        return $this->isenterprise;
    }

    /**
     * Set openid
     *
     * @param string $openid
     *
     * @return PioneerparkMember
     */
    public function setOpenid($openid)
    {
        $this->openid = $openid;

        return $this;
    }

    /**
     * Get openid
     *
     * @return string
     */
    public function getOpenid()
    {
        return $this->openid;
    }

    /**
     * Set mobile
     *
     * @param string $mobile
     *
     * @return PioneerparkMember
     */
    public function setMobile($mobile)
    {
        $this->mobile = $mobile;

        return $this;
    }

    /**
     * Get mobile
     *
     * @return string
     */
    public function getMobile()
    {
        return $this->mobile;
    }

    /**
     * Set level
     *
     * @param integer $level
     *
     * @return PioneerparkMember
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return integer
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set parentid
     *
     * @param integer $parentid
     *
     * @return PioneerparkMember
     */
    public function setParentid($parentid)
    {
        $this->parentid = $parentid;

        return $this;
    }

    /**
     * Get parentid
     *
     * @return integer
     */
    public function getParentid()
    {
        return $this->parentid;
    }

    /**
     * Set credit
     *
     * @param float $credit
     *
     * @return PioneerparkMember
     */
    public function setCredit($credit)
    {
        $this->credit = $credit;

        return $this;
    }

    /**
     * Get credit
     *
     * @return float
     */
    public function getCredit()
    {
        return $this->credit;
    }

    /**
     * Set lastloginip
     *
     * @param string $lastloginip
     *
     * @return PioneerparkMember
     */
    public function setLastloginip($lastloginip)
    {
        $this->lastloginip = $lastloginip;

        return $this;
    }

    /**
     * Get lastloginip
     *
     * @return string
     */
    public function getLastloginip()
    {
        return $this->lastloginip;
    }

    /**
     * Set lastlogintime
     *
     * @param \DateTime $lastlogintime
     *
     * @return PioneerparkMember
     */
    public function setLastlogintime($lastlogintime)
    {
        $this->lastlogintime = $lastlogintime;

        return $this;
    }

    /**
     * Get lastlogintime
     *
     * @return \DateTime
     */
    public function getLastlogintime()
    {
        return $this->lastlogintime;
    }

    /**
     * Set profileid
     *
     * @param integer $profileid
     *
     * @return PioneerparkMember
     */
    public function setProfileid($profileid)
    {
        $this->profileid = $profileid;

        return $this;
    }

    /**
     * Get profileid
     *
     * @return integer
     */
    public function getProfileid()
    {
        return $this->profileid;
    }

    /**
     * Set regtime
     *
     * @param \DateTime $regtime
     *
     * @return PioneerparkMember
     */
    public function setRegtime($regtime)
    {
        $this->regtime = $regtime;

        return $this;
    }

    /**
     * Get regtime
     *
     * @return \DateTime
     */
    public function getRegtime()
    {
        return $this->regtime;
    }

    /**
     * Set enable
     *
     * @param boolean $enable
     *
     * @return PioneerparkMember
     */
    public function setEnable($enable)
    {
        $this->enable = $enable;

        return $this;
    }

    /**
     * Get enable
     *
     * @return boolean
     */
    public function getEnable()
    {
        return $this->enable;
    }

    /**
     * Specify data which should be serialized to JSON
     * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
     * @return mixed data which can be serialized by <b>json_encode</b>,
     * which is a value of any type other than a resource.
     * @since 5.4.0
     */
    public function jsonSerialize()
    {
        return [
            'uid' => $this->getUid(),
            'isenterprise' => $this->getIsenterprise(),
            'openid' => $this->getOpenid(),
            'mobile' => $this->getMobile(),
            'level ' => $this->getLevel (),
            'parentid' => $this->getParentid(),
            'credit' => $this->getCredit(),
            'lastloginip' => $this->getLastloginip(),
            'lastlogintime' => $this->getLastlogintime(),
            'profileid' => $this->getProfileid(),
            'regtime' => $this->getRegtime(),
            'enable' => $this->getEnable(),
        ];
    }

    /**
     * Whether a offset exists
     * @link https://php.net/manual/en/arrayaccess.offsetexists.php
     * @param mixed $offset <p>
     * An offset to check for.
     * </p>
     * @return boolean true on success or false on failure.
     * </p>
     * <p>
     * The return value will be casted to boolean if non-boolean was returned.
     * @since 5.0.0
     */
    public function offsetExists($offset)
    {
        // TODO: Implement offsetExists() method.
    }

    /**
     * Offset to retrieve
     * @link https://php.net/manual/en/arrayaccess.offsetget.php
     * @param mixed $offset <p>
     * The offset to retrieve.
     * </p>
     * @return mixed Can return all value types.
     * @since 5.0.0
     */
    public function offsetGet($offset)
    {
        $method = 'get' . ucfirst($offset);
        return $this->$method();
    }

    /**
     * Offset to set
     * @link https://php.net/manual/en/arrayaccess.offsetset.php
     * @param mixed $offset <p>
     * The offset to assign the value to.
     * </p>
     * @param mixed $value <p>
     * The value to set.
     * </p>
     * @return void
     * @since 5.0.0
     */
    public function offsetSet($offset, $value)
    {
        // TODO: Implement offsetSet() method.
    }

    /**
     * Offset to unset
     * @link https://php.net/manual/en/arrayaccess.offsetunset.php
     * @param mixed $offset <p>
     * The offset to unset.
     * </p>
     * @return void
     * @since 5.0.0
     */
    public function offsetUnset($offset)
    {
        // TODO: Implement offsetUnset() method.
    }
}
