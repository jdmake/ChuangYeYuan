<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/8/4
// +----------------------------------------------------------------------


namespace AppBundle\Custom\Entry;


class AbsEntry implements \JsonSerializable
{
    /**
     * 返回JSON格式
     * @return array|mixed
     * @throws \ReflectionException
     */
    public function jsonSerialize()
    {
        return $this->toArray();
    }

    /**
     * 转为Array格式
     * @throws \ReflectionException
     */
    protected function toArray() {
        $results = [];
        $ref = new \ReflectionClass($this);
        foreach ($ref->getProperties() as $property) {
            $method = "get" . ucfirst($property->getName());
            if(method_exists($this, $method)) {
                $results[$property->getName()] = $this->$method();
            }
        }
        return $results;
    }
}