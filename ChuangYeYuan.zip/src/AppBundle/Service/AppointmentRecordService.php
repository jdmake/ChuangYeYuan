<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/8/5
// +----------------------------------------------------------------------


namespace AppBundle\Service;


use AppBundle\Entity\PioneerparkAppointmentRecord;

class AppointmentRecordService extends AbsService
{
    /**
     * 获取全部预约记录
     * @param $uid
     * @return PioneerparkAppointmentRecord[]|array
     */
    public function getAllByUid($uid)
    {
        $em = $this->getEm();
        $query = $em->createQueryBuilder();
        $query->select('a.id, a.date, a.time, a.status, b.title, b.price')
            ->from('AppBundle:PioneerparkAppointmentRecord', 'a')
            ->innerJoin('AppBundle:PioneerparkMeetingroom', 'b', 'WITH', 'a.rid=b.id')
            ->orderBy('a.status', 'asc')
            ;

        $res = $query->getQuery()->getResult();
        return $res;
    }

    /**
     * 获取记录
     * @param $id
     * @return PioneerparkAppointmentRecord|object|null
     */
    public function getDetailById($id)
    {
        return $this->getDoctrine()->getRepository('AppBundle:PioneerparkAppointmentRecord')
            ->find($id);
    }

    /**
     * 是否已经预约
     * @param $date
     * @param $rid
     * @return bool
     */
    public function isExist($date, $time, $rid)
    {
        $em = $this->getEm();
        $query = $em->createQueryBuilder();
        $and = $query->expr()->andX();
        $query->select('a')
            ->from('AppBundle:PioneerparkAppointmentRecord', 'a')
            ->where($query->expr()->andX(
                $query->expr()->eq('a.date', ':date'),
                $query->expr()->eq('a.rid', ':rid'),
                $query->expr()->eq('a.status', ':status'),
                $query->expr()->like('a.time', ':time')
            ))
            ->setParameter('date', $date)
            ->setParameter('rid', $rid)
            ->setParameter('status', 1)
            ->setParameter('time', "%{$time}%");

        $res = $query->getQuery()->getResult();
        return count($res) > 0 ? true : false;
    }

    /**
     * 创建预约记录
     * @param $id
     * @param $uid
     * @param $date
     * @param $time
     * @return int
     * @throws \Exception
     */
    public function createRecord($id, $uid, $date, $time)
    {
        $entry = new PioneerparkAppointmentRecord();
        $entry->setRid($id);
        $entry->setUid($uid);
        $entry->setDate($date);
        $entry->setTime($time);
        $entry->setStatus(0);
        $entry->setCreateAt(new \DateTime());

        $this->create($entry);

        return $entry->getId();
    }
}