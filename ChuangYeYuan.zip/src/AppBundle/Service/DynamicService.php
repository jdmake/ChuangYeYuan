<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/8/4
// +----------------------------------------------------------------------


namespace AppBundle\Service;

use AppBundle\Entity\PioneerparkDongtai;
use Doctrine\ORM\Query\Expr\OrderBy;

/**
 * 动态服务
 */
class DynamicService extends AbsService
{
    public function getPageList($cate, $page, $size)
    {
        $em = $this->getEm();
        $query = $em->createQueryBuilder();
        $query->select('a')
            ->from('AppBundle:PioneerparkDongtai', 'a')
            ->orderBy('a.createAt', 'desc')
            ->where('a.status=:status')
            ->setParameter('status', 1)
            ->setFirstResult(($page - 1) * $size)
            ->setMaxResults($size);

        if ($cate) {
            $query->andWhere('a.cate=:cate')
                ->setParameter('cate', $cate);
        }

        $total = $this->getTotal($query);

        $res = $query->getQuery()->getResult();
        return [
            'list' => $res,
            'pageSize' => intval(ceil($total / $size)),
            'total' => $total,
        ];
    }

    /**
     * 获取全部
     */
    public function findAll()
    {
        $em = $this->getEm();
        $order = new OrderBy();
        $order->add('a.sort', 'desc');
        $order->add('a.id', 'desc');

        $query = $em->createQueryBuilder();
        $query->select('a')
            ->from('AppBundle:PioneerparkDongtaiCategory', 'a')
            ->orderBy($order);

        return $query->getQuery()->getResult();
    }

    /**
     * 创建动态信息
     * @param $uid
     * @param $mid
     * @param $cate
     * @param array $data
     * @return int
     * @throws \Doctrine\ORM\OptimisticLockException
     * @throws \Exception
     */
    public function createDongTaiData($uid, $mid, $cate, array $data = [])
    {
        $entry = new PioneerparkDongtai();
        $entry->setCate($cate);
        $entry->setUid($uid);
        $entry->setMid($mid);
        $entry->setTitle($data['title']);
        $entry->setContent($data['content']);
        $entry->setPicture($data['picture']);
        $entry->setIsquality(false);
        $entry->setIsrecommend(false);
        $entry->setTag('');
        $entry->setCreateAt(new \DateTime());
        $entry->setStatus(0);

        $this->getEm()->persist($entry);
        $this->getEm()->flush();

        return $entry->getId();
    }

    /**
     * 是否存在待审核的动态
     */
    public function isExsitWaitHandle($uid)
    {
        $res = $this->getDoctrine()->getRepository('AppBundle:PioneerparkDongtai')
            ->findOneBy([
                'uid' => $uid,
                'status' => 0
            ]);
        return $res ? true : false;
    }

    /**
     * 获取详情
     * @param $id
     * @return PioneerparkDongtai|object|null
     */
    public function getDetail($id)
    {
        $res = $this->getDoctrine()->getRepository('AppBundle:PioneerparkDongtai')
            ->findOneBy([
                'id' => $id,
            ]);
        return $this->toArray($res);
    }

    /**
     * 浏览量增加
     * @param $id
     * @throws \Doctrine\ORM\OptimisticLockException
     */
    public function setIncVisit($id) {
        $entry = $this->getDoctrine()->getRepository('AppBundle:PioneerparkDongtai')->find($id);
        if($entry) {
            $entry->setVisit($entry->getVisit() + 1);
            $this->getEm()->flush();
        }
    }
}