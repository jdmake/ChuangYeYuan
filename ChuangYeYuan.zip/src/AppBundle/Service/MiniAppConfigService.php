<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/7/26
// +----------------------------------------------------------------------


namespace AppBundle\Service;

/**
 * 微信小程序配置参数
 */
class MiniAppConfigService
{
    private $appid = 'wx690c0e7fca2f65cf';

    private $secret = 'f1d1e6c14160f989337b2c1daa0b1736';

    /**
     * @return string
     */
    public function getAppid()
    {
        return $this->appid;
    }

    /**
     * @return string
     */
    public function getSecret()
    {
        return $this->secret;
    }


}