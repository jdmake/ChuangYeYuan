<?php

namespace YuZhi\TableingBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class YuZhiTableingBundle extends Bundle
{
}
