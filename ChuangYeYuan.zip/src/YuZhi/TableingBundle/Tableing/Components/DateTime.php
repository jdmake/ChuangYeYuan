<?php
// +----------------------------------------------------------------------
// | Author: jdmake <503425061@qq.com>
// +----------------------------------------------------------------------
// | Date: 2019/7/24
// +----------------------------------------------------------------------


namespace YuZhi\TableingBundle\Tableing\Components;


class DateTime implements TableComponentInterface
{
    private $format = '';

    /**
     * DateTime constructor.
     * @param string $format
     */
    public function __construct($format)
    {
        $this->format = $format;
    }


    /**
     * @param $pk_value
     * @param \DateTime $value
     * @return mixed
     */
    public function render($pk_value, $value)
    {
        return date($this->format, $value->getTimestamp());
    }
}